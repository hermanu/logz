/* Shared screen mockups — help, one-shot, detail, empty, error */

/* ============== HELP / --help ============== */
const ScreenHelp = () => (
  <TermFrame title="$ logf --help" w={720} h={480}>
    <div style={{ whiteSpace: "pre", fontSize: 12 }}>
{`${""}`}
      <span style={{ color: "var(--accent, #e85a4f)", fontWeight: 700 }}>logf</span> {C.dim("— filter, follow & analyze logs")}
{"\n\n"}
{C.mid("USAGE")}{"\n"}
{`  logf [flags] [files...]
  logf -f /var/log/app.log
  cat events.json | logf --json --level=error
`}
{"\n"}
{C.mid("FILTERS")}{"\n"}
{`  -l, --level   `}{C.dim("min severity (debug|info|warn|error|fatal)")}{"\n"}
{`  -s, --since   `}{C.dim("relative window (e.g. 5m, 1h, 24h)")}{"\n"}
{`  -m, --match   `}{C.dim("regex against message field")}{"\n"}
{`  -q, --query   `}{C.dim("query expr (e.g. service:api AND level:>=warn)")}{"\n"}
{`  -F, --field   `}{C.dim("field=value (repeatable)")}{"\n"}
{"\n"}
{C.mid("MODES")}{"\n"}
{`  -f, --follow      `}{C.dim("tail new lines as they arrive")}{"\n"}
{`  -i, --interactive `}{C.dim("open the TUI")}{"\n"}
{`      --stats       `}{C.dim("print summary table & exit")}{"\n"}
{"\n"}
{C.mid("FORMAT")}{"\n"}
{`      --json     `}{C.dim("input is JSON; auto-parse fields")}{"\n"}
{`  -o, --output   `}{C.dim("text | json | tsv | logfmt")}{"\n"}
{`      --no-color `}{C.dim("disable ANSI colors")}{"\n"}
{"\n"}
{C.mid("EXAMPLES")}{"\n"}
{C.dim("  # tail with severity floor")}{"\n"}
{`  $ logf -f -l warn app.log`}{"\n\n"}
{C.dim("  # everything from one trace, expanded")}{"\n"}
{`  $ logf -q 'trace_id:4f3a*' --json -o text`}{"\n\n"}
{C.dim("  # quick error rate over last hour")}{"\n"}
{`  $ logf --stats --since 1h *.log`}
    </div>
  </TermFrame>
);

/* ============== ONE-SHOT GREP RESULT ============== */
const ScreenOneShot = () => (
  <TermFrame title="$ logf -l error --since 15m app.log" w={720} h={420}>
    <div style={{ fontSize: 12 }}>
      {[
        ["12:01:10","ERROR","billing"    ,"retry exhausted — dropping event evt_8a92f4c1"],
        ["12:01:15","ERROR","worker-pool","smtp 421 — temp failure, requeue in 30s"],
        ["12:01:21","FATAL","worker-pool","unhandled panic — goroutine leak detected"],
        ["12:02:44","ERROR","api-gateway","jwt verification failed: token expired"],
        ["12:03:12","ERROR","api-gateway","db pool exhausted (max=50, in_use=50)"],
        ["12:03:55","ERROR","api-gateway","upstream timeout ECONNREFUSED 10.0.4.12"],
        ["12:04:01","ERROR","api-gateway","db pool exhausted (max=50, in_use=50)"],
        ["12:04:07","ERROR","api-gateway","circuit breaker OPEN for billing-svc"],
        ["12:04:12","ERROR","api-gateway","jwt verification failed: token expired"],
        ["12:04:17","ERROR","api-gateway","panic recovered — nil pointer"],
        ["12:04:18","ERROR","api-gateway","upstream timeout ECONNREFUSED 10.0.4.12"],
      ].map(([t,l,s,m],i)=>(
        <Row key={i}>
          {C.dim(t)} <Lvl l={l}/> {C.mid(s.padEnd(12))}
          <span style={{ flex: 1 }}>{m}</span>
        </Row>
      ))}
      <div style={{ marginTop: 12, color: "#7a7a80", borderTop: "1px dashed #1f1f22", paddingTop: 6 }}>
        {C.dim("──")} 11 matches in 2,184 lines · 15m window · 0.04s {C.dim("──")}
      </div>
      <div style={{ marginTop: 8 }}>
        <span style={{ color: "var(--accent, #e85a4f)" }}>$</span> <span style={{ background: "#e6e4dd", color: "#0d0d0e", padding: "0 4px" }}> </span>
      </div>
    </div>
  </TermFrame>
);

/* ============== DETAIL EXPANSION ============== */
const ScreenDetail = () => (
  <TermFrame title="logf · entry detail" w={720} h={460}>
    <div style={{ display: "flex", gap: 10, marginBottom: 8 }}>
      <Lvl l="ERROR"/>
      {C.dim("12:04:17.894 UTC")}
      <span style={{ flex: 1 }}></span>
      {C.dim("entry 42 / 84")}
    </div>
    <div style={{ borderTop: "1px solid #1f1f22", paddingTop: 8, fontSize: 12 }}>
      <div style={{ marginBottom: 6 }}>
        <span style={{ color: "#e6e4dd", fontWeight: 600 }}>panic recovered in handler /v1/checkout — nil pointer dereference</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: "0 16px", color: "#9a9a9f" }}>
        <div>{C.dim("service")}</div><div>api-gateway</div>
        <div>{C.dim("env")}</div><div>prod-us-east-1</div>
        <div>{C.dim("host")}</div><div>ip-10-0-3-44</div>
        <div>{C.dim("trace_id")}</div><div>4f3a82c1ef912b21cee04488d23a17b2</div>
        <div>{C.dim("span_id")}</div><div>9c2ea14f</div>
        <div>{C.dim("user_id")}</div><div>u_88412</div>
        <div>{C.dim("route")}</div><div>POST /v1/checkout</div>
        <div>{C.dim("status")}</div><div>502</div>
        <div>{C.dim("dur_ms")}</div><div>30041</div>
      </div>
      <div style={{ color: "#7a7a80", marginTop: 10, marginBottom: 4 }}>STACK</div>
      <div style={{ whiteSpace: "pre", color: "#9a9a9f" }}>
{`  main.checkout
      /app/handlers/checkout.go:142
  main.(*server).handle
      /app/server/server.go:88
  net/http.HandlerFunc.ServeHTTP
      /usr/local/go/src/net/http/server.go:2122`}
      </div>
    </div>
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 22, background: "#161618", borderTop: "1px solid #1f1f22", padding: "2px 12px", color: "#7a7a80", fontSize: 11, display: "flex", gap: 14 }}>
      <span>{C.inv(" j/k ")} prev/next</span>
      <span>{C.inv(" t ")} all in trace</span>
      <span>{C.inv(" y ")} yank json</span>
      <span style={{ flex: 1 }}></span>
      <span>{C.inv(" esc ")} back</span>
    </div>
  </TermFrame>
);

/* ============== STATS / SUMMARY (one-shot) ============== */
const ScreenStats = () => (
  <TermFrame title="$ logf --stats --since 1h *.log" w={720} h={420}>
    <div style={{ whiteSpace: "pre", fontSize: 12 }}>
{C.dim("┌──── summary · last 1h ──────────────────────────┐")}{"\n"}
{C.dim("│")}  events    <span style={{ color: "#e6e4dd" }}>12,438</span>{"        "}error rate  <span style={{ color: "var(--accent, #e85a4f)" }}>0.66%</span>  {C.dim("│")}{"\n"}
{C.dim("│")}  span      12:01 → 13:01    files       <span style={{ color: "#e6e4dd" }}>3</span>     {C.dim(" │")}{"\n"}
{C.dim("└──────────────────────────────────────────────────┘")}{"\n\n"}
{C.mid("BY LEVEL")}{"\n"}
{`  FATAL   `}<span style={{ color: "var(--accent, #e85a4f)" }}>▍</span>{`           2`}{"\n"}
{`  ERROR   `}<span style={{ color: "var(--accent, #e85a4f)" }}>██▌</span>{`         82`}{"\n"}
{`  WARN    `}<span style={{ color: "#d6c27a" }}>█████████▏</span>{`     314`}{"\n"}
{`  INFO    `}<span style={{ color: "#9ab7c7" }}>████████████████████████████████</span>{` 11,000`}{"\n"}
{`  DEBUG   `}<span style={{ color: "#7a7a80" }}>███▏</span>{`         1,040`}{"\n\n"}
{C.mid("BY SERVICE")}{"\n"}
{`  api-gateway   7,711  `}<span style={{ color: "#9a9a9f" }}>████████████████████████</span>{"\n"}
{`  auth-svc      2,318  `}<span style={{ color: "#9a9a9f" }}>███████</span>{"\n"}
{`  worker-pool   1,406  `}<span style={{ color: "#9a9a9f" }}>████</span>{"\n"}
{`  billing       1,003  `}<span style={{ color: "#9a9a9f" }}>███</span>{"\n\n"}
{C.mid("TOP MESSAGES (clustered)")}{"\n"}
{`  44× upstream timeout ECONNREFUSED ${C.dim("(api-gateway)")}`}{"\n"}
{`  18× jwt verification failed       ${C.dim("(api-gateway)")}`}{"\n"}
{`  12× db pool exhausted             ${C.dim("(api-gateway)")}`}
    </div>
  </TermFrame>
);

/* ============== EMPTY STATE ============== */
const ScreenEmpty = () => (
  <TermFrame title="logf -f -l error" w={720} h={300}>
    <div style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", color: "#7a7a80" }}>
      <div style={{ fontSize: 28, color: "#3a3a3d", marginBottom: 6 }}>{"·  ·  ·"}</div>
      <div style={{ color: "#e6e4dd" }}>Quiet. No matching events.</div>
      <div style={{ marginTop: 6, fontSize: 11 }}>watching <span style={{ color: "#e6e4dd" }}>app.log</span> · level≥error · since 15m ago</div>
      <div style={{ marginTop: 14, fontSize: 11 }}>
        try {C.inv(" - l warn ")} {C.dim("·")} {C.inv(" --since 1h ")} {C.dim("·")} {C.inv(" / ")} {C.dim("to search")}
      </div>
      <div style={{ marginTop: 18, color: "var(--accent, #e85a4f)" }}>● tailing</div>
    </div>
  </TermFrame>
);

/* ============== ERROR STATE ============== */
const ScreenError = () => (
  <TermFrame title="$ logf /var/log/app.log" w={720} h={300}>
    <div style={{ fontSize: 12 }}>
      <div style={{ color: "var(--accent, #e85a4f)" }}>✗ logf: cannot read /var/log/app.log</div>
      <div style={{ color: "#9a9a9f", marginTop: 4 }}>permission denied (uid=1000, file is mode 0640 owned by root:adm)</div>
      <div style={{ marginTop: 14, color: "#7a7a80" }}>{C.dim("did you mean:")}</div>
      <div style={{ marginTop: 4 }}>
        $ <span style={{ color: "#e6e4dd" }}>sudo logf /var/log/app.log</span>{"\n"}
      </div>
      <div style={{ marginTop: 4 }}>
        $ <span style={{ color: "#e6e4dd" }}>logf ~/logs/app.log</span> {C.dim("# the user-writable copy")}
      </div>
      <div style={{ marginTop: 18 }}>
        $ <span style={{ background: "#e6e4dd", color: "#0d0d0e", padding: "0 4px" }}> </span>
      </div>
    </div>
  </TermFrame>
);

Object.assign(window, { ScreenHelp, ScreenOneShot, ScreenDetail, ScreenStats, ScreenEmpty, ScreenError });
