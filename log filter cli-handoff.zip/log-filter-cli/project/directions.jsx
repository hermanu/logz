/* 4 overall TUI direction mockups for `logf --interactive` */

/* ============== A. SPLIT-PANE (k9s style) ============== */
const DirSplitPane = () => (
  <TermFrame title="logf --interactive" sub="split-pane" w={920} h={520}>
    {/* command bar */}
    <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
      {C.dim("›")} <span>filter</span> {C.dim(":")} <span style={{ color: "#e6e4dd" }}>level&gt;=ERROR service:api-gateway</span>
      <span style={{ flex: 1 }}></span>
      {C.dim("12,438 lines · 84 matches · 1h window")}
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "150px 1fr 280px", gap: 8, height: "calc(100% - 28px)" }}>
      {/* sidebar */}
      <div style={{ borderRight: "1px solid #1f1f22", paddingRight: 8 }}>
        <div style={{ color: "#7a7a80", fontSize: 11, marginBottom: 4 }}>LEVELS</div>
        {[["FATAL","2"],["ERROR","82"],["WARN","314"],["INFO","11k"],["DEBUG","0"]].map(([l,n],i)=>(
          <div key={l} style={{ display: "flex", justifyContent: "space-between", color: i<2 ? "#e6e4dd":"#7a7a80" }}>
            <span>{i<2?"■":"□"} {l}</span><span>{C.dim(n)}</span>
          </div>
        ))}
        <div style={{ color: "#7a7a80", fontSize: 11, marginTop: 12, marginBottom: 4 }}>SERVICES</div>
        {[["api-gateway",true],["auth-svc",false],["billing",false],["worker-pool",false]].map(([s,on])=>(
          <div key={s} style={{ color: on ? "#e6e4dd" : "#7a7a80" }}>{on?"■":"□"} {s}</div>
        ))}
        <div style={{ color: "#7a7a80", fontSize: 11, marginTop: 12, marginBottom: 4 }}>WINDOW</div>
        <div>{C.dim("○")} 5m</div>
        <div>{C.dim("○")} 15m</div>
        <div>{C.hi("●")} 1h</div>
        <div>{C.dim("○")} 24h</div>
      </div>
      {/* log list */}
      <div style={{ overflow: "hidden" }}>
        {[
          ["12:04:18.221","ERROR","api-gateway","upstream timeout: connect ECONNREFUSED 10.0.4.12:8080"],
          ["12:04:17.894","ERROR","api-gateway","panic recovered in handler /v1/checkout — nil pointer"],
          ["12:04:15.310","WARN", "api-gateway","rate-limit near threshold (920/1000) for tenant=acme"],
          ["12:04:12.117","ERROR","api-gateway","jwt verification failed: token expired"],
          ["12:04:09.882","INFO", "api-gateway","request POST /v1/checkout 502 in 30,041ms"],
          ["12:04:07.554","ERROR","api-gateway","circuit breaker OPEN for billing-svc (3/3 failures)"],
          ["12:04:05.220","WARN", "api-gateway","slow query >2s on shard-3"],
          ["12:04:01.001","ERROR","api-gateway","db pool exhausted (max=50, in_use=50)"],
          ["12:03:58.776","INFO", "api-gateway","health check ok"],
          ["12:03:55.443","ERROR","api-gateway","upstream timeout: connect ECONNREFUSED 10.0.4.12:8080"],
        ].map(([t,l,s,m],i)=>(
          <Row key={i} sel={i===1}>
            {C.dim(t)} <Lvl l={l}/> {C.mid(s.padEnd(11))}
            <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m}</span>
          </Row>
        ))}
      </div>
      {/* detail */}
      <div style={{ borderLeft: "1px solid #1f1f22", paddingLeft: 8, fontSize: 11 }}>
        <div style={{ color: "#7a7a80", marginBottom: 4 }}>ENTRY · 12:04:17.894</div>
        <div><Lvl l="ERROR"/> {C.mid("api-gateway")}</div>
        <div style={{ marginTop: 8 }}>{C.dim("trace_id ")}<span>4f3a…b21c</span></div>
        <div>{C.dim("span_id  ")}<span>9c2e…</span></div>
        <div>{C.dim("user_id  ")}<span>u_88412</span></div>
        <div>{C.dim("route    ")}<span>POST /v1/checkout</span></div>
        <div style={{ marginTop: 8, color: "#7a7a80" }}>MESSAGE</div>
        <div style={{ whiteSpace: "pre-wrap" }}>panic recovered in handler{"\n"}/v1/checkout — nil pointer{"\n"}dereference at line 142</div>
        <div style={{ marginTop: 8, color: "#7a7a80" }}>STACK</div>
        <div style={{ color: "#7a7a80" }}>main.checkout+0x42{"\n"}main.handle+0x88{"\n"}…</div>
      </div>
    </div>
    {/* status footer is implied by border */}
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 22, background: "#161618", borderTop: "1px solid #1f1f22", padding: "2px 12px", color: "#7a7a80", fontSize: 11, display: "flex", gap: 14 }}>
      <span>{C.inv(" ? ")} help</span>
      <span>{C.inv(" / ")} search</span>
      <span>{C.inv(" f ")} filter</span>
      <span>{C.inv(" t ")} tail</span>
      <span style={{ flex: 1 }}></span>
      <span>↑↓ navigate</span>
      <span>⏎ expand</span>
    </div>
  </TermFrame>
);

/* ============== B. STREAM (lnav style) ============== */
const DirStream = () => (
  <TermFrame title="logf -f" sub="stream" w={920} h={520}>
    {/* top bar with query + density sparkline */}
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "2px 4px", borderBottom: "1px dashed #1f1f22", marginBottom: 6 }}>
      <span>{C.dim("query ▸")} <span>level:&gt;=warn</span></span>
      <span style={{ flex: 1 }}></span>
      <Spark data={[2,3,2,4,5,3,6,9,12,18,24,32,28,21,17,14,10,8,5,3,2,1,2,4,7]}/>
      <span>{C.dim("last 60m")}</span>
    </div>
    {/* full-width log stream */}
    <div style={{ height: "calc(100% - 56px)", overflow: "hidden" }}>
      {[
        ["12:01:02","INFO" ,"auth-svc"   ,"user login ok user_id=u_88412 method=oauth_google"],
        ["12:01:04","INFO" ,"api-gateway","GET /v1/me 200 in 41ms"],
        ["12:01:09","WARN" ,"billing"    ,"retry 1/3 — stripe webhook signature mismatch"],
        ["12:01:09","WARN" ,"billing"    ,"retry 2/3 — stripe webhook signature mismatch"],
        ["12:01:10","ERROR","billing"    ,"retry exhausted — dropping event evt_8a92…"],
        ["12:01:12","INFO" ,"worker-pool","job picked up id=j_4421 queue=email"],
        ["12:01:14","DEBUG","worker-pool","SMTP connect smtp.relay:587 tls=on"],
        ["12:01:15","ERROR","worker-pool","smtp 421 — temp failure, requeue in 30s"],
        ["12:01:18","WARN" ,"api-gateway","slow query >2s on shard-3 q=SELECT…orders"],
        ["12:01:19","INFO" ,"api-gateway","POST /v1/checkout 200 in 312ms"],
        ["12:01:21","FATAL","worker-pool","unhandled panic — goroutine leak detected"],
        ["12:01:22","INFO" ,"worker-pool","supervisor restarting worker-3 (exit=2)"],
        ["12:01:25","INFO" ,"auth-svc"   ,"token refresh user_id=u_22118"],
        ["12:01:27","WARN" ,"api-gateway","rate-limit near threshold (920/1000) tenant=acme"],
        ["12:01:30","INFO" ,"api-gateway","GET /v1/orders 200 in 88ms"],
      ].map(([t,l,s,m],i)=>(
        <Row key={i}>
          {C.dim(t)} <Lvl l={l}/> {C.mid(s.padEnd(12))}
          <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m}</span>
        </Row>
      ))}
    </div>
    {/* status */}
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 22, background: "#161618", borderTop: "1px solid #1f1f22", padding: "2px 12px", color: "#7a7a80", fontSize: 11, display: "flex", gap: 14 }}>
      <span style={{ color: "var(--accent, #e85a4f)" }}>● LIVE</span>
      <span>2,143 lines/s</span>
      <span>buffer 18% of 100MB</span>
      <span style={{ flex: 1 }}></span>
      <span>{C.inv(" SPC ")} pause</span>
      <span>{C.inv(" / ")} query</span>
    </div>
  </TermFrame>
);

/* ============== C. PALETTE (fzf style) ============== */
const DirPalette = () => (
  <TermFrame title="logf" sub="palette / fzf" w={920} h={520}>
    {/* match list, newest at bottom (above the prompt) */}
    <div style={{ display: "flex", flexDirection: "column", justifyContent: "flex-end", height: "calc(100% - 28px)" }}>
      <div style={{ color: "#7a7a80", fontSize: 11, marginBottom: 4 }}>{C.dim("84 / 12,438")}</div>
      {[
        ["12:04:01","ERROR","api-gateway","db pool exhausted (max=50, in_use=50)"],
        ["12:04:05","WARN" ,"api-gateway","slow query >2s on shard-3"],
        ["12:04:07","ERROR","api-gateway","circuit breaker OPEN for billing-svc"],
        ["12:04:09","INFO" ,"api-gateway","request POST /v1/checkout 502 in 30,041ms"],
        ["12:04:12","ERROR","api-gateway","jwt verification failed: token expired"],
        ["12:04:15","WARN" ,"api-gateway","rate-limit near threshold (920/1000)"],
        ["12:04:17","ERROR","api-gateway","panic recovered — nil pointer"],
        ["12:04:18","ERROR","api-gateway","upstream timeout: connect ECONNREFUSED"],
      ].map(([t,l,s,m],i,arr)=>{
        const sel = i === arr.length - 1;
        // highlight letters matching "timeout" or "checkout"
        const hilite = (txt) => {
          const re = /(timeout|checkout|exhausted|panic|expired|circuit)/gi;
          const parts = txt.split(re);
          return parts.map((p,j) => re.test(p) ? <span key={j} style={{ background: "var(--accent, #e85a4f)", color: "#0d0d0e", padding: "0 1px" }}>{p}</span> : <span key={j}>{p}</span>);
        };
        return (
          <Row key={i} sel={sel}>
            <span style={{ width: 10, color: "var(--accent, #e85a4f)" }}>{sel ? "▌" : " "}</span>
            {C.dim(t)} <Lvl l={l}/> {C.mid(s)}
            <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{hilite(m)}</span>
          </Row>
        );
      })}
      {/* preview pane (when one match selected) */}
      <div style={{ borderTop: "1px dashed #1f1f22", marginTop: 6, padding: "6px 4px", color: "#9a9a9f", fontSize: 11 }}>
        <div>{C.dim("preview ▸")} api-gateway · 12:04:18.221 · trace=4f3a…b21c</div>
        <div style={{ color: "#e6e4dd", marginTop: 2, whiteSpace: "pre" }}>{`upstream timeout: connect ECONNREFUSED 10.0.4.12:8080
  caller=net/http.(*Transport).dialConn
  retries=3  duration=30.041s`}</div>
      </div>
    </div>
    {/* prompt at bottom — fzf style */}
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "4px 14px", background: "#161618", borderTop: "1px solid #1f1f22", display: "flex", gap: 8, alignItems: "center" }}>
      <span style={{ color: "var(--accent, #e85a4f)" }}>❯</span>
      <span>timeout</span>
      <span style={{ width: 8, height: 14, background: "#e6e4dd", display: "inline-block", verticalAlign: "middle" }}></span>
      <span style={{ flex: 1 }}></span>
      <span style={{ color: "#7a7a80", fontSize: 11 }}>↑↓ pick · ⏎ open · ⌃R regex · ⌃L level</span>
    </div>
  </TermFrame>
);

/* ============== D. DASHBOARD (btop style) ============== */
const DirDashboard = () => {
  const sparkErr = [1,0,2,1,3,4,2,1,5,8,12,18,22,17,14,10,7,5,4,3,2,1,1,2];
  const sparkAll = [22,18,24,28,30,29,32,34,38,40,42,44,46,42,38,36,30,28,26,24,22,20,21,23];
  return (
    <TermFrame title="logf stats" sub="dashboard" w={920} h={520}>
      {/* top stats row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 8 }}>
        <div style={{ border: "1px solid #1f1f22", padding: "6px 10px" }}>
          <div style={{ color: "#7a7a80", fontSize: 11 }}>┌ ERRORS / MIN ┐</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span style={{ fontSize: 22, color: "var(--accent, #e85a4f)", fontWeight: 700 }}>22</span>
            <span style={{ color: "var(--accent, #e85a4f)" }}>▲ 4×</span>
          </div>
          <Spark data={sparkErr} color="var(--accent, #e85a4f)"/>
        </div>
        <div style={{ border: "1px solid #1f1f22", padding: "6px 10px" }}>
          <div style={{ color: "#7a7a80", fontSize: 11 }}>┌ TOTAL EVENTS ┐</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span style={{ fontSize: 22, fontWeight: 700 }}>12,438</span>
            <span style={{ color: "#7a7a80" }}>last 1h</span>
          </div>
          <Spark data={sparkAll}/>
        </div>
        <div style={{ border: "1px solid #1f1f22", padding: "6px 10px" }}>
          <div style={{ color: "#7a7a80", fontSize: 11 }}>┌ TOP SERVICE ┐</div>
          <div style={{ fontSize: 16, fontWeight: 600 }}>api-gateway</div>
          <div style={{ color: "#7a7a80" }}>62% · 7,711 events</div>
        </div>
      </div>
      {/* level breakdown bar */}
      <div style={{ border: "1px solid #1f1f22", padding: "6px 10px", marginBottom: 8 }}>
        <div style={{ color: "#7a7a80", fontSize: 11, marginBottom: 4 }}>┌ LEVEL BREAKDOWN ┐</div>
        {[
          ["FATAL", 2,    "▍",                   "var(--accent, #e85a4f)"],
          ["ERROR", 82,   "███▍",                "var(--accent, #e85a4f)"],
          ["WARN",  314,  "█████████████▏",      "#d6c27a"],
          ["INFO",  11000,"████████████████████████████████████████", "#9ab7c7"],
          ["DEBUG", 1040, "████▏",               "#7a7a80"],
        ].map(([l,n,bar,color])=>(
          <div key={l} style={{ display: "flex", gap: 10 }}>
            <span style={{ width: 56 }}><Lvl l={l}/></span>
            <span style={{ color, flex: 1, whiteSpace: "nowrap", overflow: "hidden" }}>{bar}</span>
            <span style={{ color: "#9a9a9f", width: 60, textAlign: "right" }}>{n.toLocaleString()}</span>
          </div>
        ))}
      </div>
      {/* recent errors table */}
      <div style={{ border: "1px solid #1f1f22", padding: "6px 10px", height: 188, overflow: "hidden" }}>
        <div style={{ color: "#7a7a80", fontSize: 11, marginBottom: 4 }}>┌ RECENT ERRORS ┐</div>
        {[
          ["12:04:18","api-gateway","upstream timeout ECONNREFUSED 10.0.4.12"],
          ["12:04:17","api-gateway","panic recovered — nil pointer"],
          ["12:04:12","api-gateway","jwt verification failed: token expired"],
          ["12:04:07","api-gateway","circuit breaker OPEN for billing-svc"],
          ["12:04:01","api-gateway","db pool exhausted (max=50, in_use=50)"],
          ["12:03:55","api-gateway","upstream timeout ECONNREFUSED 10.0.4.12"],
          ["12:03:48","worker-pool","unhandled panic — goroutine leak"],
        ].map(([t,s,m],i)=>(
          <Row key={i}>
            {C.dim(t)} <Lvl l="ERROR"/> {C.mid(s.padEnd(12))}
            <span style={{ flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{m}</span>
          </Row>
        ))}
      </div>
    </TermFrame>
  );
};

Object.assign(window, { DirSplitPane, DirStream, DirPalette, DirDashboard });
