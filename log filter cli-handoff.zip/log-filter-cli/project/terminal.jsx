/* Reusable sketchy terminal bezel + ANSI-ish helpers for log content */

const TermFrame = ({ title = "logf", w, h, children, dim = false, sub }) => (
  <div style={{
    width: w, height: h,
    background: "var(--term-bg, #0d0d0e)",
    color: "var(--term-fg, #e6e4dd)",
    border: "1.5px solid #1a1a1c",
    borderRadius: 10,
    boxShadow: "0 1px 0 rgba(255,255,255,0.04) inset, 0 12px 30px -18px rgba(0,0,0,0.6)",
    fontFamily: "'JetBrains Mono', ui-monospace, monospace",
    fontSize: 12,
    lineHeight: 1.55,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    opacity: dim ? 0.65 : 1,
  }}>
    {/* title bar */}
    <div style={{
      height: 26, flex: "0 0 26px",
      background: "#161618",
      borderBottom: "1px solid #1f1f22",
      display: "flex", alignItems: "center",
      padding: "0 10px",
      gap: 6,
    }}>
      <span style={{ width: 10, height: 10, borderRadius: 5, background: "#3a3a3d" }}></span>
      <span style={{ width: 10, height: 10, borderRadius: 5, background: "#3a3a3d" }}></span>
      <span style={{ width: 10, height: 10, borderRadius: 5, background: "#3a3a3d" }}></span>
      <div style={{ flex: 1, textAlign: "center", color: "#7a7a80", fontSize: 11 }}>
        {title}{sub ? <span style={{ color: "#52525a" }}> — {sub}</span> : null}
      </div>
      <span style={{ width: 40 }}></span>
    </div>
    <div style={{ flex: 1, padding: "10px 14px", overflow: "hidden", position: "relative" }}>
      {children}
    </div>
  </div>
);

/* ANSI-ish colored span helpers (greyscale + severity accent only) */
const C = {
  dim: (s) => <span style={{ color: "#5a5a60" }}>{s}</span>,
  mid: (s) => <span style={{ color: "#9a9a9f" }}>{s}</span>,
  hi:  (s) => <span style={{ color: "#e6e4dd" }}>{s}</span>,
  err: (s) => <span style={{ color: "var(--accent, #e85a4f)", fontWeight: 600 }}>{s}</span>,
  warn:(s) => <span style={{ color: "#d6c27a" }}>{s}</span>,
  info:(s) => <span style={{ color: "#9ab7c7" }}>{s}</span>,
  ok:  (s) => <span style={{ color: "#8fae8a" }}>{s}</span>,
  hl:  (s) => <span style={{ background: "var(--accent, #e85a4f)", color: "#0d0d0e", padding: "0 2px" }}>{s}</span>,
  inv: (s) => <span style={{ background: "#e6e4dd", color: "#0d0d0e", padding: "0 4px" }}>{s}</span>,
};

/* Severity badge — small block, mostly grey, ERROR/FATAL get the accent */
const Lvl = ({ l }) => {
  const styles = {
    DEBUG: { bg: "#26262a", fg: "#7a7a80" },
    INFO:  { bg: "#2a323a", fg: "#9ab7c7" },
    WARN:  { bg: "#3a3528", fg: "#d6c27a" },
    ERROR: { bg: "var(--accent, #e85a4f)", fg: "#0d0d0e" },
    FATAL: { bg: "var(--accent, #e85a4f)", fg: "#0d0d0e" },
  };
  const s = styles[l] || styles.INFO;
  return <span style={{ background: s.bg, color: s.fg, padding: "0 6px", fontWeight: 600, fontSize: 11, letterSpacing: 0.3 }}>{l.padEnd(5)}</span>;
};

/* Hand-drawn annotation that points at a terminal */
const Annot = ({ children, top, left, right, w = 180, arrow = "↘" }) => (
  <div style={{
    position: "absolute",
    top, left, right,
    width: w,
    fontFamily: "'Kalam', 'Caveat', cursive",
    fontWeight: 400,
    fontSize: 16,
    lineHeight: 1.25,
    color: "#3a3a3d",
    transform: "rotate(-1.5deg)",
    pointerEvents: "none",
  }}>
    <span style={{ fontSize: 22, marginRight: 4 }}>{arrow}</span>
    {children}
  </div>
);

/* Row helpers used in many screens */
const Row = ({ children, sel }) => (
  <div style={{
    display: "flex", gap: 10, padding: "1px 4px",
    background: sel ? "#1f1f22" : "transparent",
    borderLeft: sel ? "2px solid var(--accent, #e85a4f)" : "2px solid transparent",
    paddingLeft: sel ? 6 : 8,
  }}>{children}</div>
);

/* Sparkline using block chars */
const Spark = ({ data, color = "#9a9a9f" }) => {
  const blocks = ["▁","▂","▃","▄","▅","▆","▇","█"];
  const max = Math.max(...data);
  return <span style={{ color, letterSpacing: 0 }}>{data.map(v => blocks[Math.round((v / max) * 7)]).join("")}</span>;
};

Object.assign(window, { TermFrame, C, Lvl, Annot, Row, Spark });
